var results = document.getElementById("results"); 
var all = document.getElementById("allquotes");
var buttons = document.getElementById("buttons");

var randomChannel = function () {
	var rColor; //This sets up the randomChannel variable to go into the following function.. 

	do {
		rColor = Math.floor(Math.random()*256); //This is multiplying random math to get a color value.
	}
	while (rColor < 150 || rColor > 250); //I believe this is limiting which random colors show up. 

	// *** THE ABOVE CODE DOES THE SAME THING 
	// *** AS THE COMMENTED CODE BELOW *** 
	// 
	// while (rColor < 150 || rColor > 250) {
	// 	// if (rColor < 150 || rColor > 250) {
	// 	// 	rColor = Math.floor(Math.random()*256);
	// 	// };
	// };
	//

	return rColor; //This just returns the random color, right? It's the result of the previous function.
};

var randomColor = function () {
	var myColor = "rgb("; 
	myColor = myColor + randomChannel();
	myColor = myColor + ",";
	myColor = myColor + randomChannel();
	myColor = myColor + ",";
	myColor = myColor + randomChannel();
	myColor = myColor + ")";		
	return myColor; This 
}; //This randomizes the colors for the quotes established in quotes.js.

var loadQuote = function (theQuote) {

	var whichQuote = theQuote.id.substr(5, 1); //This is randomizing the quote, connected to quotes.js.

	var ourBox = document.getElementById("specificquote"); //This is declaring the variable ourBox and pulling the quotes.js doc, right?
	ourBox.innerHTML = "";  //This is setting and returning ourBox to the HTML
	ourBox.style.backgroundColor = randomQuotes[whichQuote].boxColor; //This styles the background color for random quotes.

	var specificQuote = document.createTextNode(
		randomQuotes[whichQuote].quote + 
		" - " + 
		randomQuotes[whichQuote].subject
	); //This is taking the specific quote quote and subject and putting them together into a text node in a variable called "specificQuote." This puts the quote before the author's name. I deleted it because I didn't want the subject to show up.

	ourBox.appendChild(specificQuote); //This establishes specificQuote as the child element and ourBox as the parent element.

};

var init = function () { 

	results.innerHTML = ""; //This refers to all the possible results in the HTML. 
	all.innerHTML = ""; //This refers to all the quotes referenced in the HTML.  
	buttons.innerHTML = ""; //This makes all this innerHTML (the HTML doc) and all the stuff attatched to it, so this refreshes the web page? 

	var r = document.createElement("div"); //This is creating an HTML tag called "div."
	var randomSelection = Math.floor(randomQuotes.length*Math.random()); //This is the function for mathematically selecting a random quote from the randomQuotes list/array. It didn't specify a number in case because the length of the array can change.
	r.className = "quoteBox"; //This is telling "r" to have the className of "quoteBox" from now on, referring to the div in the HTML that has the same name.

	var p = document.createTextNode(
		"Random item index at " + 
		randomSelection + 
		": " + 
		randomQuotes[randomSelection].quote + 
		" - " + 
		randomQuotes[randomSelection].subject); //This is taking a random quote and subject and putting them together in a textNode.

	r.appendChild(p); //This is making "p" a child of "r".
	r.style.backgroundColor = randomQuotes[randomSelection].boxColor; //This is assigning "r" a random background color.
	results.appendChild(r); //This is appending "r" to results as a child element with a random background color and everything.


	for (i = 0; i < randomQuotes.length; i++) { //This is a "for loop" that is randomly choosing quotes.

		var btnMake = document.createElement("button"); //This is creating the button element and callin git "button" in the code/HTML.
		var btnText = document.createTextNode(randomQuotes[i].subject); //This is declaring the button text as a new element and creating a new text node in the HTML. 
		var item; //This is declaring a variable called "item.""
		// var a = randomQuotes[i].boxColor;
		
		btnMake.appendChild(btnText); //This adds text to the buttons and establishes the text as the child element with btnMake as the parent.
		btnMake.id = "quote" + i; //This is connecting the connecting the button to the quotes to the interation in the for loop. It's creating a button for specific quotes. 
		btnMake.addEventListener("click", function () {
			loadQuote(this); //This is a function that loads a quote every time a button is clicked.
		})
		
		buttons.appendChild(btnMake); //This is making btnMake a child element of the "button" element. 

		item = document.createTextNode(

			i+1 +
			" [index of " + 
			i + 
			"] " +
			": " + 
			randomQuotes[i].quote + 
			" \u2014 " + 
			randomQuotes[i].subject

		); //This is a string that is building an index of quotes and then adding the quote and subject. This adds everything in the index to the quote box along with the author (or in my case, the subject).

		var itemDiv = document.createElement("div"); //This is creating an item in the HTML doc called "div.""
		itemDiv.className = "quoteBox"; //This is attaching/assigning the class name of "quotebox" to the itemDiv in the HTML.
		itemDiv.appendChild(item); //This is making the variable "item," which was declared earlier, a child of the item Div. 
		
		all.appendChild(itemDiv);
		itemDiv.style.backgroundColor = randomColor(); //

	}

};

init(); //This ini

document.getElementById("reload").addEventListener("click", init); //This waits for a button click to reload the page. This is specifically for the relaod button. It also generates a random quote b/c that is tied to the "init" function.