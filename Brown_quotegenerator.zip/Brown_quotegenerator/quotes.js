var randomQuotes = [

	{ quote: "Love takes off makes that we cannot live without and know we cannot live within.", 
	  subject: "Love", 
	  boxColor: "#00ff00"
	}, 
	
	{ quote: "I love America more than any other county in the world and, exactly for that reason, I insist on the right to critize her.", 
	  subject: "Patriotism", 
	  boxColor: "#ffaaaa"
	},

	{ quote: "Artists are here to disturb the peace.", 
	  subject: "The artist", 
	  boxColor: "#aa9900"
	},

	{ quote: "You think your pain and your heartbreak are unprecedented in the history of the world, but then you read.", 
	  subject: "Reading", 
	  boxColor: "#cc00cc"
	},
    
    { quote: "Anyone who is trying to be conscious must begin to dismiss the vocabulary which we've used so long to cover it up, to lie about the way things are.", 
	  subject: "Guilt", 
	  boxColor: "#cc00cc"
	}

];

// var someArray = [];
// var anotherOne = [1, "words", {key:"value"}, [1,2,3], false];

// var anyObject = { 

// 	key: "value",
// 	anotherKey: 123,
// 	yetAnotherKey: false,
// 	aMethodKey: function () {},
// 	anotherAnotherAnother: 4

// }

// var window = {
// 	alert: function (message) {}
// };


